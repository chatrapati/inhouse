import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hrmanagement',
  templateUrl: './hrmanagement.component.html',
  styleUrls: ['./hrmanagement.component.css']
})
export class HrmanagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
