import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usercreation',
  templateUrl: './usercreation.component.html',
  styleUrls: ['./usercreation.component.css']
})
export class UsercreationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
